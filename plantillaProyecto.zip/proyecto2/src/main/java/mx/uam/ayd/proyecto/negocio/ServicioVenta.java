package mx.uam.ayd.proyecto.negocio;

import org.springframework.beans.factory.annotation.Autowired;

import lombok.extern.slf4j.Slf4j;
import mx.uam.ayd.proyecto.datos.VentaRepository;

@Slf4j
public class ServicioVenta {

	@Autowired
	private VentaRepository ventaRepository;
	
	
}
